# Thief Escape 2

2D Android stealth game.

Features:
- Multiple rooms
- Furniture, walls and doors
- Resident patrol and vision cone
- Hide spots
- Police chase/search after alarm
- 3 levels with increasing difficulty
- Loot collection and escape
- Touch joystick and action buttons
- Custom-drawn graphics, no external image assets required

Open the project in Android Studio, wait for Gradle sync, then Run.

To make an APK:
Build -> Build Bundle(s) / APK(s) -> Build APK(s)
