package com.example.thiefescape

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import kotlin.math.*

class GameView(context: Context) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private var last = System.currentTimeMillis()
    private var level = 1
    private var state = "PLAY"
    private var hidden = false
    private var alarm = false
    private var player = PointF(110f, 500f)
    private var resident = PointF(610f, 180f)
    private var residentTarget = 0
    private var police = PointF(-100f, -100f)
    private var joystickTouch = -1
    private var moveX = 0f
    private var moveY = 0f
    private var actionPressed = false
    private var hidePressed = false
    private var loot = mutableListOf<PointF>()
    private var collected = 0
    private var totalLoot = 3
    private var hideSpots = mutableListOf<RectF>()
    private var doors = mutableListOf<RectF>()
    private var obstacles = mutableListOf<RectF>()
    private var waypoints = mutableListOf<PointF>()

    init {
        isFocusable = true
        setLayerType(View.LAYER_TYPE_SOFTWARE, null)
        setupLevel()
    }

    private fun setupLevel() {
        state = "PLAY"
        alarm = false
        hidden = false
        collected = 0
        player = PointF(100f, 520f)
        resident = PointF(610f, 170f)
        police = PointF(-100f, -100f)
        residentTarget = 0
        moveX = 0f; moveY = 0f
        loot = mutableListOf()
        hideSpots = mutableListOf()
        doors = mutableListOf()
        obstacles = mutableListOf()
        waypoints = mutableListOf()

        val count = 2 + level
        totalLoot = count
        for (i in 0 until count) {
            loot.add(PointF(150f + i * 115f, if (i % 2 == 0) 155f else 410f))
        }

        hideSpots.add(RectF(365f, 105f, 435f, 180f))
        hideSpots.add(RectF(760f, 370f, 845f, 455f))
        if (level >= 2) hideSpots.add(RectF(460f, 390f, 540f, 470f))

        obstacles.add(RectF(250f, 120f, 350f, 205f)) // table
        obstacles.add(RectF(690f, 120f, 840f, 200f)) // kitchen
        obstacles.add(RectF(270f, 350f, 430f, 440f)) // sofa
        obstacles.add(RectF(600f, 330f, 740f, 445f)) // bed
        obstacles.add(RectF(810f, 110f, 900f, 245f)) // cabinet

        doors.add(RectF(425f, 235f, 475f, 265f))
        doors.add(RectF(565f, 235f, 615f, 265f))
        doors.add(RectF(760f, 235f, 810f, 265f))

        waypoints.add(PointF(610f, 170f))
        waypoints.add(PointF(735f, 170f))
        waypoints.add(PointF(735f, 300f))
        waypoints.add(PointF(520f, 300f))
        waypoints.add(PointF(520f, 170f))
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val sx = width / 1000f
        val sy = height / 600f
        c.save()
        c.scale(sx, sy)

        drawWorld(c)
        drawVision(c)
        drawCharacters(c)
        drawLoot(c)
        drawHud(c)
        drawControls(c)

        if (state != "PLAY") drawOverlay(c)
        c.restore()

        val now = System.currentTimeMillis()
        val dt = min(0.04f, (now - last) / 1000f)
        last = now
        if (state == "PLAY") update(dt)
        postInvalidateOnAnimation()
    }

    private fun drawWorld(c: Canvas) {
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, 0f, 0f, 600f, Color.rgb(35,38,44), Color.rgb(18,20,24), Shader.TileMode.CLAMP)
        c.drawRect(0f,0f,1000f,600f,p)
        p.shader = null

        // rooms
        room(c, 30f, 70f, 330f, 260f, "LIVING")
        room(c, 350f, 70f, 650f, 260f, "HALL")
        room(c, 670f, 70f, 970f, 260f, "KITCHEN")
        room(c, 30f, 285f, 470f, 560f, "BEDROOM")
        room(c, 490f, 285f, 970f, 560f, "MAIN ROOM")

        // walls
        p.color = Color.rgb(65,68,75)
        p.strokeWidth = 10f
        p.style = Paint.Style.STROKE
        c.drawRect(30f,70f,970f,560f,p)
        c.drawLine(340f,70f,340f,260f,p)
        c.drawLine(660f,70f,660f,260f,p)
        c.drawLine(30f,275f,970f,275f,p)
        c.drawLine(480f,285f,480f,560f,p)
        p.style = Paint.Style.FILL

        for (d in doors) {
            p.color = Color.rgb(135,92,55)
            c.drawRoundRect(d, 8f, 8f, p)
            p.color = Color.rgb(215,175,100)
            c.drawCircle(d.right-10f, d.centerY(), 4f, p)
        }

        // furniture
        furniture(c, obstacles[0], Color.rgb(118,78,45), "TABLE")
        furniture(c, obstacles[1], Color.rgb(70,86,92), "KITCHEN")
        furniture(c, obstacles[2], Color.rgb(85,55,65), "SOFA")
        furniture(c, obstacles[3], Color.rgb(78,62,85), "BED")
        furniture(c, obstacles[4], Color.rgb(96,70,48), "CABINET")

        for (r in hideSpots) {
            p.color = Color.argb(180, 42, 120, 90)
            c.drawRoundRect(r, 10f,10f,p)
            p.color = Color.WHITE
            p.textSize = 16f
            p.textAlign = Paint.Align.CENTER
            c.drawText("HIDE", r.centerX(), r.centerY()+5f,p)
        }

        p.color = Color.rgb(55,160,90)
        c.drawRoundRect(885f, 475f, 945f, 530f, 10f,10f,p)
        p.color = Color.WHITE
        p.textSize = 16f
        p.textAlign = Paint.Align.CENTER
        c.drawText("EXIT",915f,505f,p)
    }

    private fun room(c: Canvas, l:Float,t:Float,r:Float,b:Float,name:String) {
        p.color = Color.rgb(47,50,57)
        p.style = Paint.Style.FILL
        c.drawRect(l,t,r,b,p)
        p.color = Color.rgb(100,104,112)
        p.textSize = 13f
        p.textAlign = Paint.Align.LEFT
        c.drawText(name,l+12f,t+22f,p)
    }

    private fun furniture(c: Canvas, r: RectF, color:Int, label:String) {
        p.setShadowLayer(12f, 0f, 8f, Color.argb(130,0,0,0))
        p.color = color
        c.drawRoundRect(r, 12f,12f,p)
        p.clearShadowLayer()
        p.color = Color.argb(70,255,255,255)
        c.drawRoundRect(r.left+8,r.top+8,r.right-8,r.top+18,6f,6f,p)
        p.color = Color.WHITE
        p.textSize = 12f
        p.textAlign = Paint.Align.CENTER
        c.drawText(label,r.centerX(),r.centerY()+4f,p)
    }

    private fun drawVision(c: Canvas) {
        if (state != "PLAY") return
        if (!hidden) {
            val dx = player.x - resident.x
            val dy = player.y - resident.y
            val angle = atan2(dy, dx)
            val facing = atan2(waypoints[(residentTarget+1)%waypoints.size].y-resident.y,
                waypoints[(residentTarget+1)%waypoints.size].x-resident.x)
            val cone = Math.toRadians(if (level == 1) 42.0 else 52.0).toFloat()
            val dist = if (level == 1) 245f else 290f
            val a1 = facing-cone
            val a2 = facing+cone
            path.reset()
            path.moveTo(resident.x,resident.y)
            path.lineTo(resident.x+cos(a1)*dist,resident.y+sin(a1)*dist)
            path.arcTo(RectF(resident.x-dist,resident.y-dist,resident.x+dist,resident.y+dist),
                Math.toDegrees(a1.toDouble()).toFloat(), Math.toDegrees((a2-a1).toDouble()).toFloat(), false)
            path.close()
            p.color = Color.argb(55,255,210,60)
            c.drawPath(path,p)

            if (alarm) {
                p.color = Color.argb(50,255,70,70)
                c.drawCircle(resident.x,resident.y,dist,p)
            }
        }
    }

    private fun drawCharacters(c: Canvas) {
        // player
        p.setShadowLayer(14f,0f,7f,Color.BLACK)
        p.color = if (hidden) Color.rgb(70,140,105) else Color.rgb(55,140,220)
        c.drawCircle(player.x,player.y,17f,p)
        p.clearShadowLayer()
        p.color = Color.WHITE
        p.textAlign = Paint.Align.CENTER
        p.textSize = 12f
        c.drawText("THIEF",player.x,player.y+4f,p)

        // resident
        p.color = Color.rgb(210,155,80)
        c.drawCircle(resident.x,resident.y,18f,p)
        p.color = Color.rgb(45,45,50)
        c.drawRect(resident.x-13,resident.y+8,resident.x+13,resident.y+22,p)
        p.color = Color.WHITE
        p.textSize = 11f
        c.drawText("RESIDENT",resident.x,resident.y-25f,p)

        if (alarm) {
            p.color = Color.rgb(225,60,60)
            p.textSize = 26f
            c.drawText("!", resident.x, resident.y-40f,p)
            p.textSize = 11f
            p.color = Color.WHITE
            c.drawText("POLICE",police.x,police.y-25f,p)
            p.color = Color.rgb(55,105,210)
            c.drawCircle(police.x,police.y,18f,p)
            p.color = Color.WHITE
            c.drawText("POLICE",police.x,police.y+4f,p)
        }
    }

    private fun drawLoot(c: Canvas) {
        for (l in loot) {
            p.setShadowLayer(10f,0f,4f,Color.BLACK)
            p.color = Color.rgb(215,180,65)
            c.drawRoundRect(l.x-14,l.y-10,l.x+14,l.y+10,5f,5f,p)
            p.clearShadowLayer()
            p.color = Color.rgb(95,65,25)
            c.drawRect(l.x-8,l.y-7,l.x+8,l.y-3,p)
            p.color = Color.WHITE
            p.textSize = 10f
            p.textAlign = Paint.Align.CENTER
            c.drawText("$",l.x,l.y+5f,p)
        }
    }

    private fun drawHud(c: Canvas) {
        p.color = Color.argb(205,12,14,18)
        c.drawRoundRect(18f,12f,390f,58f,14f,14f,p)
        p.color = Color.WHITE
        p.textAlign = Paint.Align.LEFT
        p.textSize = 18f
        c.drawText("LEVEL $level   LOOT $collected/$totalLoot",32f,42f,p)

        val status = when {
            alarm -> "ALARM: POLICE SEARCHING"
            hidden -> "HIDDEN"
            else -> "STEALTH"
        }
        p.color = if (alarm) Color.rgb(255,90,90) else if (hidden) Color.rgb(90,210,140) else Color.WHITE
        p.textAlign = Paint.Align.RIGHT
        p.textSize = 15f
        c.drawText(status,980f,42f,p)
    }

    private fun drawControls(c: Canvas) {
        // joystick
        p.color = Color.argb(90,255,255,255)
        c.drawCircle(105f,505f,58f,p)
        p.color = Color.argb(150,255,255,255)
        c.drawCircle(105f+moveX*30f,505f+moveY*30f,27f,p)

        // action
        p.color = if (actionPressed) Color.rgb(80,160,220) else Color.argb(185,40,50,65)
        c.drawRoundRect(830f,470f,955f,525f,16f,16f,p)
        p.color = Color.WHITE
        p.textSize = 17f
        p.textAlign = Paint.Align.CENTER
        c.drawText("ACTION",892f,504f,p)

        p.color = if (hidePressed) Color.rgb(70,170,115) else Color.argb(185,40,65,55)
        c.drawRoundRect(690f,470f,815f,525f,16f,16f,p)
        p.color = Color.WHITE
        c.drawText("HIDE",752f,504f,p)
    }

    private fun drawOverlay(c: Canvas) {
        p.color = Color.argb(220,0,0,0)
        c.drawRect(0f,0f,1000f,600f,p)
        p.color = Color.WHITE
        p.textAlign = Paint.Align.CENTER
        p.textSize = 44f
        val title = when(state) {
            "WIN" -> "HOUSE ROBBED"
            "LOSE" -> "CAUGHT"
            else -> "PAUSED"
        }
        c.drawText(title,500f,250f,p)
        p.textSize = 20f
        if (state == "WIN" && level < 3) {
            c.drawText("Tap ACTION for next level",500f,305f,p)
        } else if (state == "WIN") {
            c.drawText("All levels complete!",500f,305f,p)
        } else {
            c.drawText("Tap ACTION to restart",500f,305f,p)
        }
    }

    private fun update(dt: Float) {
        // resident patrol
        val target = waypoints[residentTarget]
        val rx = target.x-resident.x
        val ry = target.y-resident.y
        val rd = hypot(rx,ry)
        if (rd < 8f) residentTarget = (residentTarget+1)%waypoints.size
        else {
            resident.x += rx/rd * (48f+level*10f)*dt
            resident.y += ry/rd * (48f+level*10f)*dt
        }

        // player
        if (!hidden) {
            val speed = 155f
            val nx = player.x + moveX*speed*dt
            val ny = player.y + moveY*speed*dt
            if (!blocked(nx, player.y)) player.x = nx
            if (!blocked(player.x, ny)) player.y = ny
            player.x = player.x.coerceIn(50f,950f)
            player.y = player.y.coerceIn(90f,535f)
        }

        // interact with loot
        if (actionPressed) {
            for (i in loot.indices.reversed()) {
                if (dist(player,loot[i]) < 42f) {
                    loot.removeAt(i)
                    collected++
                }
            }
            if (collected == totalLoot && RectF(885f,475f,945f,530f).contains(player.x,player.y)) {
                state = if (level < 3) "WIN" else "WIN"
            }
            actionPressed = false
        }

        // hide toggle
        if (hidePressed) {
            var near = false
            for (r in hideSpots) {
                if (r.inset(-25f,-25f).contains(player.x,player.y)) near = true
            }
            if (near) hidden = !hidden
            hidePressed = false
        }

        // resident detection
        if (!hidden && inVision(player, resident)) {
            alarm = true
        }

        if (alarm) {
            if (police.x < 0f) police = PointF(930f,520f)
            if (!hidden) {
                val dx = player.x-police.x
                val dy = player.y-police.y
                val d = hypot(dx,dy)
                if (d > 10f) {
                    police.x += dx/d * (120f+level*15f)*dt
                    police.y += dy/d * (120f+level*15f)*dt
                }
                if (d < 24f) state = "LOSE"
            } else {
                // search around last visible location
                val dx = resident.x-police.x
                val dy = resident.y-police.y
                val d = hypot(dx,dy)
                if (d > 35f) {
                    police.x += dx/d * 85f*dt
                    police.y += dy/d * 85f*dt
                }
            }
        }
    }

    private fun inVision(pos: PointF, r: PointF): Boolean {
        val dx = pos.x-r.x
        val dy = pos.y-r.y
        val d = hypot(dx,dy)
        if (d > if(level==1) 245f else 290f) return false
        val target = waypoints[(residentTarget+1)%waypoints.size]
        val fx = target.x-r.x
        val fy = target.y-r.y
        val dot = (dx*fx+dy*fy)/(max(0.001f,hypot(dx,dy))*max(0.001f,hypot(fx,fy)))
        return dot > cos(Math.toRadians(if(level==1) 21.0 else 26.0)).toFloat()
    }

    private fun blocked(x:Float,y:Float):Boolean {
        for (r in obstacles) if (r.inset(-18f,-18f).contains(x,y)) return true
        return false
    }

    private fun dist(a:PointF,b:PointF)=hypot(a.x-b.x,a.y-b.y)

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val x = e.x * 1000f / width
        val y = e.y * 600f / height
        when(e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val idx = e.actionIndex
                val px = e.getX(idx)*1000f/width
                val py = e.getY(idx)*600f/height
                if (px < 220f && py > 420f) {
                    joystickTouch = e.getPointerId(idx)
                    updateJoystick(px,py)
                } else if (px in 680f..820f && py > 450f) {
                    hidePressed = true
                } else if (px in 820f..970f && py > 450f) {
                    actionPressed = true
                    if (state != "PLAY") {
                        if (state == "WIN" && level < 3) {
                            level++
                            setupLevel()
                        } else {
                            level = 1
                            setupLevel()
                        }
                    }
                }
            }
            MotionEvent.ACTION_MOVE -> {
                val id = joystickTouch
                if (id >= 0) {
                    val idx = e.findPointerIndex(id)
                    if (idx >= 0) updateJoystick(e.getX(idx)*1000f/width,e.getY(idx)*600f/height)
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                if (e.getPointerId(e.actionIndex) == joystickTouch) {
                    joystickTouch = -1
                    moveX = 0f; moveY = 0f
                }
            }
        }
        return true
    }

    private fun updateJoystick(x:Float,y:Float) {
        val dx = x-105f
        val dy = y-505f
        val d = hypot(dx,dy)
        if (d < 8f) { moveX=0f; moveY=0f }
        else {
            val m = min(1f,d/55f)
            moveX = dx/d*m
            moveY = dy/d*m
        }
    }
}
